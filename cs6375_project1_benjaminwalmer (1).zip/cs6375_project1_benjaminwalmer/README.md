# instructions on how to run cs6375\_project1\_code:



-run all coding blocks sequentially, no libraries should need to be imported or installed if using GoogleColab which I used.

-total runtime should be roughly 15-20 minutes

